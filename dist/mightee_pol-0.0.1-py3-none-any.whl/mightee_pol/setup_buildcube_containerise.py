#!python3
'''
Short helper script 
'''
'''
